import { Inline, route, values } from '../document-helpers.tsx';

declare module 'solid-js' {
	namespace JSX {
		interface ExplicitAttributes {
			onload: string;
		}
	}
}

const fonts =
	'https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,300..900;1,300..900&family=Lato:ital,wght@0,400;0,700;1,400&family=Montserrat+Alternates&family=Rethink+Sans:ital,wght@0,400..800;1,400..800&family=Source+Code+Pro:ital,wght@0,200..900;1,200..900&display=swap';

export default function HeadContent() {
	return (
		<>
			{!values.usingSEO && <meta charset="utf-8" />}
			<meta
				name="viewport"
				content="width=device-width, initial-scale=1.0, shrink-to-fit=no"
			/>
			<meta
				name="theme-color"
				media="(prefers-color-scheme: dark)"
				content="#434c5e"
			/>
			<link
				rel="apple-touch-icon"
				sizes="57x57"
				href={route('assets/ico/apple-icon-57x57.png')}
			/>
			<link
				rel="apple-touch-icon"
				sizes="60x60"
				href={route('assets/ico/apple-icon-60x60.png')}
			/>
			<link
				rel="apple-touch-icon"
				sizes="72x72"
				href={route('assets/ico/apple-icon-72x72.png')}
			/>
			<link
				rel="apple-touch-icon"
				sizes="76x76"
				href={route('assets/ico/apple-icon-76x76.png')}
			/>
			<link
				rel="apple-touch-icon"
				sizes="114x114"
				href={route('assets/ico/apple-icon-114x114.png')}
			/>
			<link
				rel="apple-touch-icon"
				sizes="120x120"
				href={route('assets/ico/apple-icon-120x120.png')}
			/>
			<link
				rel="apple-touch-icon"
				sizes="144x144"
				href={route('assets/ico/apple-icon-144x144.png')}
			/>
			<link
				rel="apple-touch-icon"
				sizes="152x152"
				href={route('assets/ico/apple-icon-152x152.png')}
			/>
			<link
				rel="apple-touch-icon"
				sizes="180x180"
				href={route('assets/ico/apple-icon-180x180.png')}
			/>
			<link
				rel="icon"
				type="image/png"
				sizes="192x192"
				href={route('assets/ico/android-icon-192x192.png')}
			/>
			<link
				rel="icon"
				type="image/png"
				sizes="32x32"
				href={route('assets/ico/favicon-32x32.png')}
			/>
			<link
				rel="icon"
				type="image/png"
				sizes="96x96"
				href={route('assets/ico/favicon-96x96.png')}
			/>
			<link
				rel="icon"
				type="image/png"
				sizes="16x16"
				href={route('assets/ico/favicon-16x16.png')}
			/>
			<link rel="icon" href={route('assets/ico/favicon.ico')} />
			<link rel="preconnect" href="https://fonts.googleapis.com" />
			<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="" />
			<Inline>
				<link
					rel="stylesheet"
					href={route('assets/css/style.css', 'inline')}
				/>
			</Inline>
			<link
				rel="stylesheet"
				href={fonts}
				media="print"
				attr:onload="this.media='all'"
			/>
		</>
	);
}
