# Games Information for Self-Hosting

### All respective games for this project have been moved to https://github.com/QuiteAFancyEmerald/HU-Archive

- Simply download the latest release and unzip in a folder named "archive"; full path will be  `./views/archive/[RESPECTIVE FILES HERE]`

### For inquires or takedowns simply contact via d9tcv6vgx@mozmail.com

## Update: Games are no longer supported on this project. Check out Truffled if you want an Unblocked Games site. 
https://truffled.lol

# If you want emulation use Obsidian

https://github.com/titaniumnetwork-dev/Obsidian